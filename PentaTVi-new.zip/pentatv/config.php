<?php
#Config file
//Site Title
$title = "PENTA TV LIVE STREAMING";

//Site URL
$site_url = "https://pentatv.live";

//Site Description
$description = "";

//Watermark image
$watermarkImage = "../images/2.png";

//Watermark link
$watermarkLink = "";

//Google Analytics tag ID
$gaCode = "";

//Preroll Ads Video (.mp4)
$prerollAds = "";

//Preroll Ads Time (seconds)
$prerollTime = 0;

//Preroll Ads External Link
$prerollLink = "";
?>