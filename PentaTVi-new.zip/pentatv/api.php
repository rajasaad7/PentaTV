<?php

$url = null ;
if(isset($_POST["chan"]) && !empty($_POST["chan"])) {
    if($_POST["chan"] == "cricket"){
        $url = "http://zero.pentatv.live/willowcrickethd/watch.php";

    }else if($_POST["chan"] == "football"){
        $url = "http://zero.pentatv.live/btsports1/watch.php";
        
    }else if($_POST["chan"] == "Wrestling"){
        $url = "http://zero.pentatv.live/starsports1en/watch.php";
        
    }else if($_POST["chan"] == "Tennis"){
        $url = "http://zero.pentatv.live/nlespn1/watch.php";
        
    }
    else if($_POST["chan"] == "Tennis"){
        $url = "http://zero.pentatv.live/btsportsespn/watch.php";
        
    }
    else if($_POST["chan"] == "UFC"){
        $url = "http://zero.pentatv.live/nlespn4/watch.php";
        
    }
    else if($_POST["chan"] == "Basketball"){
        $url = "http://zero.pentatv.live/starsports3/watch.php";
        
    }
 else {
    header("Location: ../index.php");
    exit;
}
}

?>