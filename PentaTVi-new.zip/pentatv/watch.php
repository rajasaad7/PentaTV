<?php
require_once "api.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
<script async="" src="https://www.googletagmanager.com/gtag/js?id=G-YNG53HN4MC"></script>
<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());
	gtag('config', 'G-YNG53HN4MC');
	</script>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="NodeTent">
   <meta name="author" content="NodeTent">
   <title>PENTA TV LIVE STREAMING</title>
   <!-- Favicon Icon -->
   <link rel="icon" type="image/png" href="../images/favicon.png">
   <!-- Bootstrap core CSS-->
   <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
   <!-- Custom fonts for this template-->
   <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
   <!-- Custom styles for this template-->
   <link href="css/style.css" rel="stylesheet">
   <!-- Owl Carousel -->
   <link rel="stylesheet" href="vendor/owl-carousel/owl.carousel.css">
   <link rel="stylesheet" href="vendor/owl-carousel/owl.theme.css">
   <script type="text/javascript" src="js/clappr.js"></script>
   <script type="text/javascript" src="https://cdn.jsdelivr.net/clappr.chromecast-plugin/latest/clappr-chromecast-plugin.min.js"></script>
   <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/clappr/clappr-level-selector-plugin@latest/dist/level-selector.min.js"></script>
   <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/mokoshalb/clappr-ads/ads.js"></script>
   <script type="text/javascript" src="js/player-error.js"></script>


   <style>
      
      @media only screen and (max-width: 600px) {

        
          .navbar , .sidebar {
            display: none;
         }

         #player {
            height: 200%;
         }

         .center {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 50%;
            margin-top: 20px;
         }

         .channel {

            width: unset;
         }

         .items {
            display: flex !important;
            flex-wrap: wrap;
            margin-left: -10px;
            margin-top: 50%;

         }

         .items .item {
            flex: 1 0 calc(33% - 10px);
            box-sizing: border-box;
            background: #343434;
            color: #ffffff;
            padding: 10px;
            margin-left: 10px;
            margin-top: 10px;
            font-weight: bold;
         }
         a{
            color: #ffffff;
         }
      }
   </style>
</head>


<body id="page-top" class="sidebar-toggled">
   <nav class="navbar navbar-expand navbar-light bg-white static-top osahan-nav sticky-top">
      &nbsp;&nbsp;

      <button class="btn btn-link btn-sm text-secondary order-1 order-sm-0" id="sidebarToggle">
         <i class="fas fa-bars"></i>
      </button> &nbsp;&nbsp;


      <!--<a class="navbar-brand mr-1" href="/"><img class="img-fluid" alt="" src="img/logo.png"></a>-->
      <!--Navbar Search -->
      <!-- <div class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-5 my-2 my-md-0 osahan-navbar-search">
            <div class="input-group">
               <input type="text" class="form-control search" onkeyup="bait(this)" placeholder="Search for...">
               <div class="input-group-append">
                  <button class="btn btn-light sort" type="button">
                  <i class="fas fa-search"></i>
                  </button>
               </div>
            </div>
         </div> -->

   </nav>
   <div id="wrapper">
      <!-- Sidebar -->
      <ul id="list" class="sidebar navbar-nav list">
         <li class="nav-item">
            <a class="channel nav-link" onclick="aedubai()" href="javascript:void(0);">AE Dubai Sports 1</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="espn1()" href="javascript:void(0);">ESPN 1</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="espn2()" href="javascript:void(0);">ESPN 2</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="espn3()" href="javascript:void(0);">ESPN 3</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="espn4()" href="javascript:void(0);">ESPN 4</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="sonysix()" href="javascript:void(0);">Sony Six</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="ptvhd()" href="javascript:void(0);">PTV Sports HD</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="ptv()" href="javascript:void(0);">PTV Sports</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="nw()" href="javascript:void(0);">NBCS Washington</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="nwp()" href="javascript:void(0);">NBCS Washington Plus</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="bt1()" href="javascript:void(0);">BT Sports 1</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="bt2()" href="javascript:void(0);">BT Sports 2</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="bt3()" href="javascript:void(0);">BT Sports 3</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="sten()" href="javascript:void(0);">Star Sports English</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="sthn()" href="javascript:void(0);">Star Sports Hindi</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="st2()" href="javascript:void(0);">Star Sports 2</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="st3()" href="javascript:void(0);">Star Sports 3</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="ns()" href="javascript:void(0);">NBC Sports</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="btespn()" href="javascript:void(0);">BT Sports ESPN</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="wc()" href="javascript:void(0);">Willow Cricket</a>

         </li>
         <li class="nav-item">
            <a class="channel nav-link" onclick="wchd()" href="javascript:void(0);">Willow Cricket HD</a>

         </li>
         
      </ul>
   <div id="content-wrapper">
      <div class="container-fluid pb-0">
         <div class="top-mobile-search">
            <div class="row">
               <div class="col-md-12">
                  <a href="https://pentatv.live">
                     <img class="img-fluid logo center" src="../images/2.png" alt="PentaTV Live">
                  </a>
               </div>
            </div>
         </div>
    
         <div class="video-block section-padding">
            <div class="row">
               <div class="col-md-12">

                  <iframe id="player" src="<?php echo $url ?>" width=100% height=720px frameborder=0 scrolling=no allowfullscreen=true marginheight=0 marginwidth=0 webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

               </div>
            </div>
         </div>
      </div>

      <div class="items" style="display: none;">
         <div class="item">
         <a class="channel nav-link" onclick="aedubai()" href="javascript:void(0);">AE Dubai Sports 1</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="espn1()" href="javascript:void(0);">ESPN 1</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="espn2()" href="javascript:void(0);">ESPN 2</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="espn3()" href="javascript:void(0);">ESPN 3</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="espn4()" href="javascript:void(0);">ESPN 4</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="sonysix()" href="javascript:void(0);">Sony Six</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="ptvhd()" href="javascript:void(0);">PTV Sports HD</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="ptv()" href="javascript:void(0);">PTV Sports</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="nw()" href="javascript:void(0);">NBCS Washington</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="nwp()" href="javascript:void(0);">NBCS Washington Plus</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="bt1()" href="javascript:void(0);">BT Sports 1</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="bt2()" href="javascript:void(0);">BT Sports 2</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="bt3()" href="javascript:void(0);">BT Sports 3</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="sten()" href="javascript:void(0);">Star Sports English</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="sthn()" href="javascript:void(0);">Star Sports Hindi</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="st2()" href="javascript:void(0);">Star Sports 2</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="st3()" href="javascript:void(0);">Star Sports 3</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="ns()" href="javascript:void(0);">NBC Sports</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="btespn()" href="javascript:void(0);">BT Sports ESPN</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="wc()" href="javascript:void(0);">Willow Cricket</a>

         </div>
         <div class="item">
         <a class="channel nav-link" onclick="wchd()" href="javascript:void(0);">Willow Cricket HD</a>

         </div>
      </div>
      <!-- /.content-wrapper -->
   </div>


   <!-- /#wrapper -->
   <!-- Bootstrap core JavaScript-->
   <script src="vendor/jquery/jquery.min.js"></script>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <!-- Core plugin JavaScript-->
   <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
   <!-- Owl Carousel -->
   <script src="vendor/owl-carousel/owl.carousel.js"></script>
   <script src="js/list.min.js"></script>
   <!-- Custom scripts for all pages-->
   <script src="js/main.js"></script>
   <script>
      function aedubai() {
         $('#player').attr('src', 'http://zero.pentatv.live/aedubaisports1/watch.php');
      }
      function espn1() {
         $('#player').attr('src', 'http://zero.pentatv.live/nlespn1/watch.php');

        
      }

      function espn2() {
         $('#player').attr('src', 'http://zero.pentatv.live/nlespn2/watch.php');


      } 
      function espn3() {
         $('#player').attr('src', 'http://zero.pentatv.live/nlespn3/watch.php');


      }

      function espn4() {
         $('#player').attr('src', 'http://zero.pentatv.live/nlespn4/watch.php');


      }

      function sonysix() {
         $('#player').attr('src', 'http://zero.pentatv.live/sonysix/watch.php');

      }

      function ptvhd() {
         $('#player').attr('src', 'http://zero.pentatv.live/ptvsports/watch.php');

      }

      function ptv() {
         $('#player').attr('src', 'http://zero.pentatv.live/ptvsports1/watch.php');


      }

      function nw() {
         $('#player').attr('src', 'http://zero.pentatv.live/nbscnwashington/watch.php');

      }

      function nwp() {
         $('#player').attr('src', 'http://zero.pentatv.live/nbcsnwashingtonplus/watch.php');


      }

      function bt1() {
         $('#player').attr('src', 'http://zero.pentatv.live/btsports1/watch.php');

      }

      function bt2() {
         $('#player').attr('src', 'http://zero.pentatv.live/btsports2/watch.php');

      }

      function bt3() {
         $('#player').attr('src', 'http://zero.pentatv.live/btsports3/watch.php');


      }

      function sten() {
         $('#player').attr('src', 'http://zero.pentatv.live/starsports1en/watch.php');

      }

      function sthn() {
         $('#player').attr('src', 'http://zero.pentatv.live/starsports1hindi/watch.php');
  

      }

      function st2() {
         $('#player').attr('src', 'http://zero.pentatv.live/starsports2/watch.php');


      }

      function st3() {
         $('#player').attr('src', 'http://zero.pentatv.live/starsports3/watch.php');


      }

      function ns() {
         $('#player').attr('src', 'http://zero.pentatv.live/nbcsportsnorthwest/watch.php');

      }

      function btespn() {
         $('#player').attr('src', 'http://zero.pentatv.live/btsportsespn/watch.php');

      }

      function wc() {
         $('#player').attr('src', 'http://zero.pentatv.live/willowcricket/watch.php');


      }

      function wchd() {
         $('#player').attr('src', 'http://zero.pentatv.live/willowcrickethd/watch.php');


      }
   </script>
   <script>
      document.addEventListener('contextmenu', event => event.preventDefault());
   </script>
   <script type="text/javascript">
      $('#player').on('contextmenu', function() {
         return false;
      });
   </script>
   <script>
      var btn = $('.item');
      btn.on('click', function(e) {
         e.preventDefault();
         $('html, body').animate({
            scrollTop: 0
         }, '300');
      });
   </script>

<script>
if($(window).width()>600){
   $("body").removeClass("sidebar-toggled");

}
</script>
<script>
   window.addEventListener('load', (event) => { 
         var iframe_attr = document.getElementById("player"); 
         iframe_attr.setAttribute("sandbox", "allow-forms allow-pointer-lock allow-same-origin allow-scripts allow-top-navigation"); 
      });       
   </script>
</body>

</html>